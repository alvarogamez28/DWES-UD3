class citaPrevia {
    
}

