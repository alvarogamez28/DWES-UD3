class medico extends Persona {
    
}