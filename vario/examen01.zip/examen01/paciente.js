class paciente extends Persona {
    constructor (numeroAfiliacion, mutualista, nombre, apellido, dni){
        this.numeroAfiliacion=numeroAfiliacion;
        this.mutualista=mutualista;
        this.nombre=nombre;
        this.apellido=apellido;
        this.dni=dni;
    }

    mostrarPaciente = () => {
        document.write(this.nombre + " " + this.apellido + " " + this.dni + this.mutualista + this.numeroAfiliacion + "<br>"); 
    }
    
}
